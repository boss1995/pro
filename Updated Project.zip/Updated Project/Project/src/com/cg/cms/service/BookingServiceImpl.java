package com.cg.cms.service;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;
import java.util.List;
import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.cg.cms.dao.BookingDaoImpl;
import com.cg.cms.dao.IBookingDao;
import com.cg.cms.dto.Booking;
import com.cg.cms.dto.Flight;
import com.cg.cms.dto.PassengerDetail;
import com.cg.cms.dto.User;
import com.cg.cms.exception.BookingException;

public class BookingServiceImpl implements IBookingService{

	IBookingDao dao;
	public BookingServiceImpl(){
		dao= new BookingDaoImpl();
	}
	/*@Override
	public Booking addBooking(Booking booking) throws BookingException {
		return dao.addBooking(booking);
	}

	@Override
	public Booking updateBooking(int id, int passengers, String classType, int fare, int seats, 
			String creditCard, String srcCity, String deptCity) throws BookingException {
		return dao.updateBooking(id, passengers, classType, fare, seats, creditCard, srcCity, deptCity);
	}

	@Override
	public List<Booking> getBookingList() throws BookingException {
		return dao.getBookingList();
	}
	
	@Override
	public Booking deleteBooking(int id) throws BookingException {
		return dao.deleteBooking(id);
	}
	
	
	@Override
	public List<Flight> getFlightList() throws BookingException {
		return dao.getFlightList(null, null);
	}
	
	
	@Override
	public boolean validateDetails(Booking booking) throws BookingException {
		return false;
		
		Pattern pattern=Pattern.compile("[a-zA-Z0-9]*@[a-zA-Z0-9].com");
		Matcher matcher= pattern.matcher(booking.getCustEmail());
		if(matcher.matches()){
			pattern= Pattern.compile("[0-9]{10}");
			matcher= pattern.matcher(booking.getCreditInfo());
			if(matcher.matches())
				return true;
			else 
				throw new BookingException("Invalid Credit Card no ");
		}
		else
			throw new BookingException("Invalid Mail Id");
		
		
		
	}*/
	@Override
	public Booking addBooking(Booking booking) throws BookingException {
		// TODO Auto-generated method stub
		return dao.addBooking(booking);
	}
	@Override
	public boolean updateBooking(String custEmail) throws BookingException {
		// TODO Auto-generated method stub
		return dao.updateBooking(custEmail);
	}
	@Override
	public Booking deleteBooking(int id) throws BookingException {
		// TODO Auto-generated method stub
		return dao.deleteBooking(id);
	}
	@Override
	public List<Flight> getFlightList(String Dep_Date, String Arr_city)
			throws BookingException {
		// TODO Auto-generated method stub
		return dao.getFlightList(Dep_Date, Arr_city);
	}
	@Override
	public String getRole(String uname, String pass) throws BookingException {
		// TODO Auto-generated method stub
		return dao.getRole(uname, pass);
	}
	@Override
	public Booking viewBooking(int id) throws BookingException {
		// TODO Auto-generated method stub
		return dao.viewBooking(id);
	}
	@Override
	public boolean updateFlightSeats(int flightno, int passengers)
			throws BookingException {
		// TODO Auto-generated method stub
		return dao.updateFlightSeats(flightno, passengers);
	}
	@Override
	public int getFare(int flightno) throws BookingException {
		// TODO Auto-generated method stub
		return dao.getFare(flightno);
	}
	@Override
	public void PassengerDetails(int bookingid, int flightno,
			String PassengerName) throws BookingException {
		// TODO Auto-generated method stub
dao.PassengerDetails(bookingid, flightno, PassengerName);
	}
	@Override
	public int FlightOccupancy(int Flightno) throws BookingException {
		// TODO Auto-generated method stub
		return dao.FlightOccupancy(Flightno);
	}
	@Override
	public List<PassengerDetail> ListAllPassengers(int flightno)
			throws BookingException {
		// TODO Auto-generated method stub
		return dao.ListAllPassengers(flightno);
	}
	@Override
	public int updateFlightTime(int Flight_no, String Dep_time, String Arr_time)
			throws BookingException {
		// TODO Auto-generated method stub
		return dao.updateFlightTime(Flight_no, Dep_time, Arr_time);
	}
	@Override
	public int updateFlightDate(int Flight_no, String Dep_Date, String Arr_Date)
			throws BookingException {
		// TODO Auto-generated method stub
		return dao.updateFlightDate(Flight_no, Dep_Date, Arr_Date);
	}
	@Override
	public int updateAirlineName(int Flight_no, String Airline)
			throws BookingException {
		// TODO Auto-generated method stub
		return dao.updateAirlineName(Flight_no, Airline);
	}
	@Override
	public List<Flight> getFlightInfoList(String depcity, String arrcity,
			String depdate) throws BookingException {
		// TODO Auto-generated method stub
		return dao.getFlightInfoList(depcity, arrcity, depdate);
	}
	
	

	}
	


