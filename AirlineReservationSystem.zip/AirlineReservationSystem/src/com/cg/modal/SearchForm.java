package com.cg.modal;

import javax.validation.constraints.Pattern;

public class SearchForm {
	@Pattern(regexp="[A-Z a-z]{1,10}",message="Invalid SourceCity")
	private  String depCity;
	@Pattern(regexp="[A-Z a-z]{1,10}",message="Invalid ArrivalCity")
	private  String arrCity;
	/*@Pattern(regexp="[0-9]",message="Invalid Date")*/
	private String depDate;
	public String getDepCity() {
		return depCity;
	}
	public void setDepCity(String depCity) {
		this.depCity = depCity;
	}
	public String getArrCity() {
		return arrCity;
	}
	public void setArrCity(String arrCity) {
		this.arrCity = arrCity;
	}
	public String getDepDate() {
		return depDate;
	}
	public void setDepDate(String depDate) {
		this.depDate = depDate;
	}
	

}
