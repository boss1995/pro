package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.Pattern;



@Entity
@Table(name = "BookingInfo")
public class Booking {
	
	@Id
	//@GeneratedValue(strategy = GenerationType.SEQUENCE, generator="seq")
	//@SequenceGenerator(name="seq", sequenceName="Booking_seq1", allocationSize=1)
	@Column(name="booking_id")
	private int bookingId;
	
	@Column(name="user_id")
	private int userId;
	
	@Column(name="cust_email")
	@Pattern(regexp="^[a-zA-Z0-9_!#$%&�*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$",message="Invalid Email Address")
	private String emailId;
	
	@Column(name="mobile_no")
	@Pattern(regexp="[0-9]{10}",message="Mobile Number should be 10 digit long.")
	private String mobileNo;
	
	@Column(name="name")
	@Pattern(regexp="[A-Za-z]{3,30}",message="Name should range between 3-15 characters")
	private String pName;
	
	
	@Column(name="age")
	private int age;
	
	
	@Column(name="gender")
	@Pattern(regexp="[M,F,T]{1}", message="Please enter from the following: M/F/T")
	private String gender;
	
	@Column(name="no_of_tickets")
	private int noOFSeats;
	
	@Column(name="total_fare")
	private String tFare;
	
	@Column(name="seat_no")
	private int seatNo;
	
	@Column(name="credit_card")
	@Pattern(regexp="[0-9]{16}",message="Mobile Number should be 10 digit long.")
	private String creditCard;
	
	@Column(name="exp_date")
	private String eDate;
	
	@Column(name="cvv")
	private int cvv;
		
	
	//getters and setters
	public int getBookingId() {
		return bookingId;
	}
	public void setBookingId(int bookingId) {
		this.bookingId = bookingId;
	}
	public int getUserId() {
		return userId;
	}
	public void setUserId(int userId) {
		this.userId = userId;
	}
	
	public String getEmailId() {
		return emailId;
	}
	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getpName() {
		return pName;
	}
	public void setpName(String pName) {
		this.pName = pName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public int getNoOFSeats() {
		return noOFSeats;
	}
	public void setNoOFSeats(int noOFSeats) {
		this.noOFSeats = noOFSeats;
	}
	public String gettFare() {
		return tFare;
	}
	public void settFare(String tFare) {
		this.tFare = tFare;
	}
	public int getSeatNo() {
		return seatNo;
	}
	public void setSeatNo(int seatNo) {
		this.seatNo = seatNo;
	}
	public String getCreditCard() {
		return creditCard;
	}
	public void setCreditCard(String creditCard) {
		this.creditCard = creditCard;
	}
	public String geteDate() {
		return eDate;
	}
	public void seteDate(String eDate) {
		this.eDate = eDate;
	}
	public int getCvv() {
		return cvv;
	}
	public void setCvv(int cvv) {
		this.cvv = cvv;
	}
	@Override
	public String toString() {
		return "BookingInfo [bookingId=" + bookingId + ", userId=" + userId
				+ ", emailId=" + emailId + ", mobileNo=" + mobileNo
				+ ", pName=" + pName + ", age=" + age + ", gender=" + gender
				+ ", noOFSeats=" + noOFSeats + ", tFare=" + tFare + ", seatNo="
				+ seatNo + ", creditCard=" + creditCard + ", eDate=" + eDate
				+ ", cvv=" + cvv + "]";
	}
	
	
}
