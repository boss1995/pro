package com.cg.entities;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="FlightInfo")
public class Flight {
	

	@Id
	@Column(name="Flight_no")
private String flightNo;
	
	@Column(name="AIRLINE")
private String airline;
	
	@Column(name="DEP_CITY")
private String depCity;
	
	@Column(name="ARR_CITY")
private String arrCity;
	
	@Column(name="DEP_DATE")
private String depDate;
	
	@Column(name="ARR_DATE")
private String arrDate;
	
	@Column(name="DEP_TIME")
private String depTime;
	
	@Column(name="ARR_TIME")
private String arrTime;
	
	@Column(name="FIRSTSEATS")
private int economySeats;
	
	@Column(name="FIRSTSEATFARE")
private int economyFare;
	
/*	@Column(name="BUSSSEATS")
private int businessSeats;
	
	@Column(name="BUSSSEATFARE")
private int businessFare;*/

	public String getFlightNo() {
		return flightNo;
	}

	public void setFlightNo(String flightNo) {
		this.flightNo = flightNo;
	}

	public String getAirline() {
		return airline;
	}

	public void setAirline(String airline) {
		this.airline = airline;
	}

	public String getDepCity() {
		return depCity;
	}

	public void setDepCity(String depCity) {
		this.depCity = depCity;
	}

	public String getArrCity() {
		return arrCity;
	}

	public void setArrCity(String arrCity) {
		this.arrCity = arrCity;
	}

	public String getDepDate() {
		return depDate;
	}

	public void setDepDate(String depDate) {
		this.depDate = depDate;
	}

	public String getArrDate() {
		return arrDate;
	}

	public void setArrDate(String arrDate) {
		this.arrDate = arrDate;
	}

	public String getDepTime() {
		return depTime;
	}

	public void setDepTime(String depTime) {
		this.depTime = depTime;
	}

	public String getArrTime() {
		return arrTime;
	}

	public void setArrTime(String arrTime) {
		this.arrTime = arrTime;
	}

	public int getEconomySeats() {
		return economySeats;
	}

	public void setEconomySeats(int economySeats) {
		this.economySeats = economySeats;
	}

	public int getEconomyFare() {
		return economyFare;
	}

	public void setEconomyFare(int economyFare) {
		this.economyFare = economyFare;
	}

	/*public int getBussinessSeats() {
		return businessSeats;
	}

	public void setBussinessSeats(int businessSeats) {
		this.businessSeats = businessSeats;
	}

	public int getBussinessFare() {
		return businessFare;
	}

	public void setBussinessFare(int businessFare) {
		this.businessFare = businessFare;
	}*/

	@Override
	public String toString() {
		return "Flight [flightNo=" + flightNo + ", airline=" + airline
				+ ", depCity=" + depCity + ", arrCity=" + arrCity
				+ ", depDate=" + depDate + ", arrDate=" + arrDate
				+ ", depTime=" + depTime + ", arrTime=" + arrTime
				+ ", economySeats=" + economySeats + ", economyFare="
				+ economyFare /*+ ", bussinessSeats=" + businessSeats
				+ ", bussinessFare=" + businessFare + "]"*/;
	}


}
