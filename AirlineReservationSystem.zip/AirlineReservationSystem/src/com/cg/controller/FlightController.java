package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;







import org.springframework.web.bind.annotation.RequestParam;

import com.cg.entities.Booking;
import com.cg.entities.Flight;
import com.cg.entities.Users;
import com.cg.exception.QueryException;
import com.cg.modal.BookingDetails;
import com.cg.modal.LoginForm;
import com.cg.modal.SearchForm;
import com.cg.service.IServiceFlight;

@Controller
public class FlightController {
	@Autowired
	IServiceFlight service;
	
	
	public IServiceFlight getService() {
		return service;
	}
	public void setService(IServiceFlight service) {
		this.service = service;
	}
	
	
	@RequestMapping("user")
	public String User(Model model){
	LoginForm l1= new  LoginForm();
	model.addAttribute("user", l1);
	return "Login";
	}	
	
	@RequestMapping("loginAction")
	public String addUser(Model model,@Valid @ModelAttribute("user") LoginForm lf,
			BindingResult errors,@RequestParam("username")String un,
			@RequestParam("password")String pw) 
			{
		if(errors.hasErrors())
		{
			return "Login";
		}
		try {
			Users u1=service.getUsers(un, pw);		
			if(u1!=null)
			{
				int userId=u1.getUserId();
				System.out.println(userId);
				model.addAttribute("userId",userId);
				String uname=u1.getUsername();
				model.addAttribute("uname",uname);
				model.addAttribute("login",u1);
				System.out.println(uname);
				return "AfterLogin";
				
				
			}
			else
			{
				model.addAttribute("msg", "User Invalid");
				return "Login";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			model.addAttribute("msg", "User Invalid");
			return "Login";
		}
		
	}
	
	@RequestMapping("registerPage")
	public String addUser(Model model)
	{
		Users u1= new Users();
		model.addAttribute("user", u1);
		return "RegisterPage";
	}
	
	@RequestMapping("userRegistrationAction")
	public String Apply(Model model,@Valid @ModelAttribute("user") Users u1,BindingResult errors)
		
	{
		if(errors.hasErrors())
			return "RegisterPage";
		else{
			service.addUser(u1);
			model.addAttribute("msg","You added sucessfully You Can Login Now And Your Id Is :");
			return "AfterRegister";
		}
	}
	
	@RequestMapping("viewFlights")
	public String search(Model model,@RequestParam("userId") int userId)
	{
		Flight f=new Flight();
		SearchForm sf=new SearchForm();
		model.addAttribute("userId",userId);
		model.addAttribute("flight",sf);
		model.addAttribute("flight",f);
		return "SearchFlight";
	}
	
	@RequestMapping("actionFlights")
	public String SearchConsumers(Model model,@Valid @ModelAttribute("flight") SearchForm sf,BindingResult errors, @RequestParam("depCity")String dc,
			@RequestParam("arrCity")String ac, @RequestParam("depDate")String dd) throws QueryException
	{
		if(errors.hasErrors())
		{
			return "SearchFlight";
		}
		else
		{
		
		try {
			List<Flight> list=service.getAllFlights(dc,ac,dd);
			if(!list.isEmpty())
			{
			model.addAttribute("list", list);
			return "DisplayFlights";
			}
			else
			{
				model.addAttribute("msg","No flights available for the requested cities");
				return "SearchFlight";
			}
		} catch (Exception e) {
			// TODO Auto-generated catch block
			model.addAttribute("msg","No flights available for the requested cities");
			return "SearchFlight";
		}}
	}
	
	@RequestMapping("addAction")
	public String addBooking(Model model,@RequestParam("fNo")String fNo)
	{
		//List<Flight> l = service.getAllFlights();
		List<Flight> list = service.getFlightlist(fNo);
		Flight f=service.getFare(fNo);
		
		int fare=f.getEconomyFare();
		Booking book = new Booking();
		model.addAttribute("list", list);
		model.addAttribute("book", book);
		model.addAttribute("fNo",fNo);
		model.addAttribute("fare",fare);
		
		return "Booked";
	}
	
	@RequestMapping("CalcFare")
	public String CalcFare(Model model, @RequestParam("fare") int fare,@RequestParam("noOFSeats") int seat)
	{
		int tfare=(seat*fare);
		model.addAttribute("tfare",tfare);
		model.addAttribute("seat",seat);
		
		return "BookTicket";
	}
	
	
	
	@RequestMapping("success")
	public String successPage(Model model, @ModelAttribute("tfare") Booking book/*,@RequestParam("userId") int userId*//*,@RequestParam("userId") int userId,
			@RequestParam("cust_email") String email, 
			@RequestParam("mobile_no") int mob,@RequestParam("name") String name,@RequestParam("age") int age,
			@RequestParam("gender") String gender,@RequestParam("no_of_tickets") int pass,
			@RequestParam("total_fare") int totalFare,@RequestParam("credit_card") String credit,
			@RequestParam("exp_date") String date,@RequestParam("cvv") int cvv, @RequestParam("seat_no") int seat*/
			)
	{
		book.setSeatNo(11);
		
	System.out.println("In Controller "+book);
		Booking b1 = service.addBooking(book);
		model.addAttribute("book", b1);
		return "Success";
	}
	
	
	@RequestMapping("updateUser")
	public String updatePage(Model model,@RequestParam("userId") int userId){		
		
		model.addAttribute("userId",userId);
		Users us=service.getUserInfo(userId);
		model.addAttribute("msg", us);		
			return "UpdateUser";
			
	}	
	@RequestMapping("updateAction")
	public String updateUser(Model model,@RequestParam("userId") int userId,@Valid @ModelAttribute("msg") Users u2, BindingResult errors){
		model.addAttribute("userId",userId);
		
		if(errors.hasErrors())
			return "UpdateUser";
		else{
			service.updateUser(u2);
			Users us=service.getUserInfo(userId);
			model.addAttribute("msg", us);			
			return "ShowUser";
		}	
		
	}	
	@RequestMapping("afterLogin")
	public String addUser(Model model,@RequestParam("userId")int userId) {		
		
				model.addAttribute("userId",userId);
				return "AfterLogin";
				
	}

			
	@RequestMapping("showGetPage")
	public String showGetPage(Model model)
	{
		//Booking c1=  new Booking();
		BookingDetails bd=new BookingDetails();
		model.addAttribute("bd", bd);
			//model.addAttribute("flight", c1);
			return "GetBookingId";
	}
	
	@RequestMapping("getAction")
	public String getBookingDetails(Model model,@Valid @ModelAttribute("bd") Booking bd,BindingResult result,
			@RequestParam("bookingId")String bId)
	{
		if(result.hasErrors())
		{
			return "GetBookingId";
		}
		else
		{
		Booking c2 =service.getBooking(Integer.parseInt(bId));
		model.addAttribute("flight", c2);
		return "GetBookingDetails";
	}}
	
	@RequestMapping("deleteBooking")
	public String showUpdateBookingPage(
			Model model, @RequestParam("booking_id") int id){
		Booking booking= service.getBooking(id);
			model.addAttribute("flight", booking);
			return "DeleteBooking";
	}
	
	@RequestMapping("confirmDelete")
	public String deleteEmployee(Model model , /*@RequestParam("userId") int userId,*/ @RequestParam("bookingId") int bookingId)
	{
		System.out.println("Int Confim Delete "+bookingId);
		service.deleteBooking(bookingId);
		model.addAttribute("deleted", "Booking Cancelled Successfully");
	/*	model.addAttribute("userId",userId);*/
		return "DeleteAction";
	}
}
